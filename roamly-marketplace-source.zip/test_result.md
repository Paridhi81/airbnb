#====================================================================================================
# START - Testing Protocol - DO NOT EDIT OR REMOVE THIS SECTION
#====================================================================================================

# THIS SECTION CONTAINS CRITICAL TESTING INSTRUCTIONS FOR BOTH AGENTS
# BOTH MAIN_AGENT AND TESTING_AGENT MUST PRESERVE THIS ENTIRE BLOCK

# Communication Protocol:
# If the `testing_agent` is available, main agent should delegate all testing tasks to it.
#
# You have access to a file called `test_result.md`. This file contains the complete testing state
# and history, and is the primary means of communication between main and the testing agent.
#
# Main and testing agents must follow this exact format to maintain testing data. 
# The testing data must be entered in yaml format Below is the data structure:
# 
## user_problem_statement: {problem_statement}
## backend:
##   - task: "Task name"
##     implemented: true
##     working: true  # or false or "NA"
##     file: "file_path.py"
##     stuck_count: 0
##     priority: "high"  # or "medium" or "low"
##     needs_retesting: false
##     status_history:
##         -working: true  # or false or "NA"
##         -agent: "main"  # or "testing" or "user"
##         -comment: "Detailed comment about status"
##
## frontend:
##   - task: "Task name"
##     implemented: true
##     working: true  # or false or "NA"
##     file: "file_path.js"
##     stuck_count: 0
##     priority: "high"  # or "medium" or "low"
##     needs_retesting: false
##     status_history:
##         -working: true  # or false or "NA"
##         -agent: "main"  # or "testing" or "user"
##         -comment: "Detailed comment about status"
##
## metadata:
##   created_by: "main_agent"
##   version: "1.0"
##   test_sequence: 0
##   run_ui: false
##
## test_plan:
##   current_focus:
##     - "Task name 1"
##     - "Task name 2"
##   stuck_tasks:
##     - "Task name with persistent issues"
##   test_all: false
##   test_priority: "high_first"  # or "sequential" or "stuck_first"
##
## agent_communication:
##     -agent: "main"  # or "testing" or "user"
##     -message: "Communication message between agents"

# Protocol Guidelines for Main agent
#
# 1. Update Test Result File Before Testing:
#    - Main agent must always update the `test_result.md` file before calling the testing agent
#    - Add implementation details to the status_history
#    - Set `needs_retesting` to true for tasks that need testing
#    - Update the `test_plan` section to guide testing priorities
#    - Add a message to `agent_communication` explaining what you've done
#
# 2. Incorporate User Feedback:
#    - When a user provides feedback that something is or isn't working, add this information to the relevant task's status_history
#    - Update the working status based on user feedback
#    - If a user reports an issue with a task that was marked as working, increment the stuck_count
#    - Whenever user reports issue in the app, if we have testing agent and task_result.md file so find the appropriate task for that and append in status_history of that task to contain the user concern and problem as well 
#
# 3. Track Stuck Tasks:
#    - Monitor which tasks have high stuck_count values or where you are fixing same issue again and again, analyze that when you read task_result.md
#    - For persistent issues, use websearch tool to find solutions
#    - Pay special attention to tasks in the stuck_tasks list
#    - When you fix an issue with a stuck task, don't reset the stuck_count until the testing agent confirms it's working
#
# 4. Provide Context to Testing Agent:
#    - When calling the testing agent, provide clear instructions about:
#      - Which tasks need testing (reference the test_plan)
#      - Any authentication details or configuration needed
#      - Specific test scenarios to focus on
#      - Any known issues or edge cases to verify
#
# 5. Call the testing agent with specific instructions referring to test_result.md
#
# IMPORTANT: Main agent must ALWAYS update test_result.md BEFORE calling the testing agent, as it relies on this file to understand what to test next.

#====================================================================================================
# END - Testing Protocol - DO NOT EDIT OR REMOVE THIS SECTION
#====================================================================================================



#====================================================================================================
# Testing Data - Main Agent and testing sub agent both should log testing data below this section
#====================================================================================================

## user_problem_statement: Airbnb-inspired marketplace clone with browse/search, listing details, booking, My Trips, favorites, filters, map toggle, and host CRUD; checkout is mocked
## backend:
##   - task: "Listings, booking, and host CRUD API"
##     implemented: true
##     working: NA
##     file: "/app/app/api/[[...path]]/route.js"
##     stuck_count: 0
##     priority: "high"
##     needs_retesting: true
##     status_history:
##         -working: "NA"
##         -agent: "main"
##         -comment: "Replaced template status API with Mongo-backed seeded stays, filtered listings, booking overlap validation, and host listing CRUD endpoints."
## frontend:
##   - task: "Airbnb-style marketplace and booking UI"
##     implemented: true
##     working: NA
##     file: "/app/app/page.js"
##     stuck_count: 0
##     priority: "high"
##     needs_retesting: true
##     status_history:
##         -working: "NA"
##         -agent: "main"
##         -comment: "Built responsive browse grid, search/filter/map controls, detail gallery, date/guest reserve flow, My Trips, favorites, and host dashboard UI. Added mocked checkout, account menu, and Coming Soon flows for messaging, identity verification, auth, language/currency, experiences, and services."
## metadata:
##   created_by: "main_agent"
##   version: "1.0"
##   test_sequence: 1
##   run_ui: false
##
## test_plan:
##   current_focus:
##     - "Browse grid and responsive Airbnb-style header"
##     - "Listing detail, date/guest selection, mocked checkout, and My Trips"
##     - "Account menu and Coming Soon placeholders"
##     - "Host dashboard create/edit/delete UI"
##   stuck_tasks: []
##   test_all: false
##   test_priority: "high_first"
##
## agent_communication:
##     -agent: "main"
##     -message: "User approved frontend testing. Test the updated UI including Coming Soon placeholders and mocked checkout. Preserve all testing protocol text."

# Backend testing results (testing agent, sequence 2)
## backend
##   - task: "Listings, booking, and host CRUD API"
##     implemented: true
##     working: true
##     file: "/app/app/api/[[...path]]/route.js"
##     stuck_count: 0
##     priority: "high"
##     needs_retesting: false
##     status_history:
##         -working: true
##         -agent: "testing"
##         -comment: "Verified against the supervisor-managed public API using /app/backend_test.py: seeded GET listings returns 8 records with UUID-like/string ids and images; Noida and category/maxPrice filters work; detail GET works; booking creation returns nights/subtotal/total and confirmed status; overlapping dates return 409; guest capacity and malformed booking/listing payloads return 400; guest booking query returns the created booking; host listing POST/GET/PUT/DELETE all work."
## agent_communication:
##     -agent: "testing"
##     -message: "Backend API verification passed all requested scenarios. Created /app/backend_test.py for repeatable API-only coverage; no application code was modified. Frontend was not tested per instruction."


# Frontend testing results (testing agent, sequence 3)
## frontend
##   - task: "Airbnb-style marketplace and booking UI"
##     implemented: true
##     working: true
##     file: "/app/app/page.js"
##     stuck_count: 0
##     priority: "high"
##     needs_retesting: false
##     status_history:
##         -working: true
##         -agent: "testing"
##         -comment: "Public UI flow verified: Roamly header, search bar, category row, 9 listing cards, listing detail gallery/Reserve card, future date selection, mocked checkout disclosure, Confirm reservation leading to My trips, favorites, filters, and map toggle all work. No React red screen or browser console errors observed in successful runs. Account/host follow-up automation was blocked by ambiguous header button targeting; menu and host controls are visually present but those subflows need a selector-focused retest."
## agent_communication:
##     -agent: "testing"
##     -message: "Core browse/detail/booking/trips and filter/map/favorite flows passed against the public URL. Checkout explicitly states no real payment is processed. Please retest account menu actions and host dashboard with a more specific selector for the top-right menu button; automation accidentally opened Search stays because header contains nested search buttons. No app code changed."
